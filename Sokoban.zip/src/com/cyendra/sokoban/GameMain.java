package com.cyendra.sokoban;

import com.cyendra.sokoban.frame.GameFrame;
/**
 * ��������Ϸ
 * @author cyendra
 * @version 1.0
 * */
public class GameMain {

	public static void main(String[] args) {
		GameFrame f = new GameFrame();
		f.setVisible(true);
	}

}
